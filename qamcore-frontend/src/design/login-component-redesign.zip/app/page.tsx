import LoginCard from "@/components/login-card";
import MeshGradientBg from "@/components/mesh-gradient-bg";

export default function Page() {
  return (
    <main className="relative flex min-h-screen items-center justify-center px-4 py-12">
      <MeshGradientBg />
      <LoginCard />
    </main>
  );
}
