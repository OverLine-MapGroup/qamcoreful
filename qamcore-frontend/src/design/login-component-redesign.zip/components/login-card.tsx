"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { KeyRound, Lock, LogIn, Sparkles } from "lucide-react";

// ─── Original logic (preserved exactly) ───
// In a real app these would come from your project:
// import { useNavigate } from "react-router-dom";
// import { login } from "../api";
// import { useAuthStore } from "../store/auth";

export default function LoginCard() {
  // const navigate = useNavigate();
  // const setAuth = useAuthStore((s) => s.setAuth);

  const [inviteCode, setInviteCode] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const submitLogin = async () => {
    setIsLoading(true);

    // const response = await login({ inviteCode, password });
    // Mock response for demo
    const response = { token: "mock-jwt-token" };

    let role: "STUDENT" | "PSYCHOLOGIST" = "STUDENT";

    if (inviteCode === "psy" && password === "123") {
      role = "PSYCHOLOGIST";
    }

    // setAuth({
    //   token: response.token,
    //   role,
    //   orgId: "KAZATU",
    // });

    // Navigation by role
    // if (role === "PSYCHOLOGIST") navigate("/dashboard");
    // else navigate("/checkin");

    console.log("[v0] Login submitted:", { role, token: response.token });

    setTimeout(() => setIsLoading(false), 1200);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 30, scale: 0.96 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
      className="w-full max-w-md"
    >
      {/* Glass card */}
      <div className="relative rounded-2xl bg-white/70 p-8 shadow-xl shadow-slate-200/50 backdrop-blur-xl border border-white/80">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15, duration: 0.5 }}
          className="mb-8 text-center"
        >
          <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-sky-400 to-indigo-500 shadow-lg shadow-sky-200/50">
            <Sparkles className="h-7 w-7 text-white" />
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-800">
            {"Welcome back"}
          </h1>
          <p className="mt-1.5 text-sm text-slate-500">
            {"Enter your invite code to continue"}
          </p>
        </motion.div>

        {/* Form */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25, duration: 0.5 }}
          className="space-y-4"
        >
          {/* Invite Code */}
          <div className="group relative">
            <label
              htmlFor="invite-code"
              className="mb-1.5 block text-sm font-medium text-slate-600"
            >
              {"Invite Code"}
            </label>
            <div className="relative">
              <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3.5">
                <KeyRound className="h-4.5 w-4.5 text-slate-400 transition-colors group-focus-within:text-sky-500" />
              </div>
              <input
                id="invite-code"
                type="text"
                placeholder="Enter your invite code"
                value={inviteCode}
                onChange={(e) => setInviteCode(e.target.value)}
                className="w-full rounded-xl border border-slate-200/80 bg-white/80 py-3 pl-11 pr-4 text-sm text-slate-800 shadow-sm shadow-slate-100 placeholder:text-slate-400 transition-all duration-200 focus:border-sky-300 focus:bg-white focus:shadow-md focus:shadow-sky-100/50 focus:outline-none focus:ring-2 focus:ring-sky-200/60"
              />
            </div>
          </div>

          {/* Password */}
          <div className="group relative">
            <label
              htmlFor="password"
              className="mb-1.5 block text-sm font-medium text-slate-600"
            >
              {"Password"}
            </label>
            <div className="relative">
              <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3.5">
                <Lock className="h-4.5 w-4.5 text-slate-400 transition-colors group-focus-within:text-sky-500" />
              </div>
              <input
                id="password"
                type="password"
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full rounded-xl border border-slate-200/80 bg-white/80 py-3 pl-11 pr-4 text-sm text-slate-800 shadow-sm shadow-slate-100 placeholder:text-slate-400 transition-all duration-200 focus:border-sky-300 focus:bg-white focus:shadow-md focus:shadow-sky-100/50 focus:outline-none focus:ring-2 focus:ring-sky-200/60"
              />
            </div>
          </div>
        </motion.div>

        {/* Submit */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.35, duration: 0.5 }}
          className="mt-6"
        >
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={submitLogin}
            disabled={isLoading || !inviteCode || !password}
            className="group relative flex w-full items-center justify-center gap-2.5 rounded-xl bg-gradient-to-r from-sky-500 to-indigo-500 px-6 py-3.5 text-sm font-semibold text-white shadow-lg shadow-sky-300/30 transition-all duration-200 hover:shadow-xl hover:shadow-sky-300/40 disabled:cursor-not-allowed disabled:opacity-50 disabled:hover:shadow-lg"
          >
            {isLoading ? (
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                className="h-5 w-5 rounded-full border-2 border-white/30 border-t-white"
              />
            ) : (
              <>
                <LogIn className="h-4.5 w-4.5 transition-transform duration-200 group-hover:translate-x-0.5" />
                <span>{"Sign In"}</span>
              </>
            )}
          </motion.button>
        </motion.div>

        {/* Footer hint */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5, duration: 0.5 }}
          className="mt-6 text-center text-xs text-slate-400"
        >
          {"Don't have an invite code? Contact your organization admin."}
        </motion.p>
      </div>
    </motion.div>
  );
}
